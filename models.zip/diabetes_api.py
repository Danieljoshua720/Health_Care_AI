
# ============================================================
# diabetes_api.py — Production FastAPI Deployment
# ============================================================
# Install: pip install fastapi uvicorn joblib scikit-learn
# Run    : uvicorn diabetes_api:app --host 0.0.0.0 --port 8080
# ============================================================

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Optional
import joblib, pandas as pd
import numpy as np

app = FastAPI(
    title="Diabetes Risk Prediction API",
    description="BRFSS-trained Random Forest model for diabetes risk classification",
    version="1.0.0"
)

# Load model at startup — not per-request
@app.on_event("startup")
async def load_model():
    global pipeline
    pipeline = DiabetesPredictionPipeline.load("models/diabetes_rf_model.pkl")

class PatientFeatures(BaseModel):
    HighBP              : int   = Field(..., ge=0, le=1)
    HighChol            : int   = Field(..., ge=0, le=1)
    CholCheck           : int   = Field(..., ge=0, le=1)
    BMI                 : float = Field(..., ge=10, le=100)
    Smoker              : int   = Field(..., ge=0, le=1)
    Stroke              : int   = Field(..., ge=0, le=1)
    HeartDiseaseorAttack: int   = Field(..., ge=0, le=1)
    PhysActivity        : int   = Field(..., ge=0, le=1)
    Fruits              : int   = Field(..., ge=0, le=1)
    Veggies             : int   = Field(..., ge=0, le=1)
    HvyAlcoholConsump   : int   = Field(..., ge=0, le=1)
    AnyHealthcare       : int   = Field(..., ge=0, le=1)
    NoDocbcCost         : int   = Field(..., ge=0, le=1)
    GenHlth             : int   = Field(..., ge=1, le=5)
    MentHlth            : int   = Field(..., ge=0, le=30)
    PhysHlth            : int   = Field(..., ge=0, le=30)
    DiffWalk            : int   = Field(..., ge=0, le=1)
    Sex                 : int   = Field(..., ge=0, le=1)
    Age                 : int   = Field(..., ge=1, le=13)
    Education           : int   = Field(..., ge=1, le=6)
    Income              : int   = Field(..., ge=1, le=8)

class PredictionResponse(BaseModel):
    prediction   : int
    label        : str
    diabetes_prob: float
    risk_tier    : str

@app.post("/predict", response_model=PredictionResponse)
async def predict(patient: PatientFeatures):
    try:
        result = pipeline.predict(patient.dict())
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health_check():
    return {"status": "healthy", "model": "diabetes_rf_v1"}
